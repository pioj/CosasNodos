﻿using System.Collections;
using System.Collections.Generic;
using NUnit.Framework.Constraints;
using UnityEditor;
using UnityEngine;
using XNodeEditor;

namespace pioj.PipoNodes
{
    [CustomNodeEditor(typeof(RoomBase))]
    public class editor_RoomBase : NodeEditor {
        
        //flags
        //private bool flipx = false;
        //private int rotate = 0;
        
        private RoomBase simpleNode;

        public override void OnBodyGUI() {
            if (simpleNode == null) simpleNode = target as RoomBase;

            // Update serialized object's representation
            serializedObject.Update();

            var yxo = 40;
            var upo = simpleNode.GetPort("up");
            if (upo!=null)  { 
                NodeEditorGUILayout.PortField(upo);
                yxo = 60;
            } 
            EditorGUILayout.Separator();
            
            if (simpleNode.room)
            {
                EditorGUI.DrawPreviewTexture(new Rect(50,yxo,base.GetWidth()/2,100),simpleNode.room, null, ScaleMode.ScaleToFit);
            }
            else
            {
                EditorGUILayout.HelpBox("No texture found!",MessageType.Warning);
                NodeEditorGUILayout.PropertyField(serializedObject.FindProperty("room"));
            }
            
            var lefto = simpleNode.GetPort("left");
            var righto = simpleNode.GetPort("right");
            if (lefto != null && righto != null)
            {
                EditorGUILayout.Space(40);
                NodeEditorGUILayout.PortPair(lefto,righto);
            }
            else if (lefto !=null) NodeEditorGUILayout.PortField(lefto);
            else if (righto !=null) NodeEditorGUILayout.PortField(righto);
            EditorGUILayout.Space(70);
            
            
            var downo = simpleNode.GetPort("down");
            if (downo!=null) NodeEditorGUILayout.PortField(downo); 
            EditorGUILayout.Separator();
            
            
            
            /*
            char checkmark = '\u2714';
            var labelito = "ROT: " + rotate + " | FLIPX: ";
            if (flipx) labelito += checkmark.ToString();
            EditorGUILayout.LabelField(labelito);
            EditorGUILayout.BeginHorizontal();
            char rotArrow = '\u21BB';
            char fliparrows = '\u21C4';
            if (GUILayout.Button(rotArrow.ToString()))
            {
                rotate += 90; 
                rotate = rotate % 360;
            }

            if (GUILayout.Button(fliparrows.ToString()))
            {
                flipx = !flipx;
            }
            EditorGUILayout.EndHorizontal();

            //EditorGUILayout.LabelField("The value is 2 ");
           // NodeEditorGUILayout.PropertyField(serializedObject.FindProperty("sum"));
            
            */
            
            // Apply property modifications
            serializedObject.ApplyModifiedProperties();
        }
    }
}
