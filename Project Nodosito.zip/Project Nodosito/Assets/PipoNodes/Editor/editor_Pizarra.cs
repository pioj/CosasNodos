﻿using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEditor;
using UnityEngine;
using XNode;
using XNodeEditor;

namespace pioj.PipoNodes
{
    [CustomNodeGraphEditor(typeof(Pizarra), "Pizarra.Settings")]
    public class editor_Pizarra : NodeGraphEditor
    {
        public override void OnGUI()
        {
            base.OnGUI();
            EditorGUILayout.Space(20);
            EditorGUILayout.BeginVertical(GUILayout.MaxWidth(100));
           
            EditorGUILayout.Separator();
            //
            var uparrowIcon = '\u25B2';
            var downarrowIcon = '\u25BC';
            //                
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("IMPORT " + uparrowIcon)) { }
            if (GUILayout.Button("EXPORT " + downarrowIcon)) { }
            EditorGUILayout.EndHorizontal();
            //
            EditorGUILayout.Separator();
            if (GUILayout.Button("GENERATE!")) { GeneraLevel();}

            EditorGUILayout.EndVertical();
        }


        private void GeneraLevel()
        {
            var piz = target as NodeGraph;

            if (piz.nodes.Count < 1) return;

            var mapa = new PizarraJson(piz.name);
            
            /*
            
            foreach (var nod in piz.nodes)
            {
              //nod.name
              //nod.GetInputValues()
              
              mapa.rooms.Add(new RoomJson(nod.name));
              
            }
            */
            
            //tema del json blablablla
            var popo = JsonUtility.ToJson(mapa, true);
            Debug.Log(popo);
        }

    }
}
