﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XNode;

namespace pioj.PipoNodes
{
    [Serializable]
    public class RoomBase : Node
    {
        [SerializeField] public Texture2D room;

    } 
    
}
