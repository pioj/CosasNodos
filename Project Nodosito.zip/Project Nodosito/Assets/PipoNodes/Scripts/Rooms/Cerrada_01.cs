﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XNode;

namespace pioj.PipoNodes
{
    public class Cerrada_01 : RoomBase
    {
        [Input, SerializeField] public RoomBase left;
      
        
        public override object GetValue(NodePort port)
        {

            RoomBase result = null;
            
            if (port.fieldName == "left") {
                result =  GetInputValue<RoomBase>("right", null);
            }

            // Hopefully this won't ever happen, but we need to return something
            // in the odd case that the port isn't "result"
            return result;
        }
    }
}

