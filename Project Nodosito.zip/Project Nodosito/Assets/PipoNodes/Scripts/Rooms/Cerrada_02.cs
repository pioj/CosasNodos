﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XNode;


namespace pioj.PipoNodes
{
    public class Cerrada_02 : RoomBase
    {
        
        [Output, SerializeField] public RoomBase right;
        
        public override object GetValue(NodePort port)
        {
            RoomBase result = null;
            
            if (port.fieldName == "right")
            {
                result = GetInputValue<RoomBase>("left", null);
            }
            
            // Hopefully this won't ever happen, but we need to return something
            // in the odd case that the port isn't "result"
            return result;
        }
    }
}


