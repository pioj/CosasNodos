﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XNode;
namespace pioj.PipoNodes
{
    public class Cruz_01 : RoomBase
    {
        [Input, SerializeField] public RoomBase left;
        [Input, SerializeField] public RoomBase up;
        [Output, SerializeField] public RoomBase right;
        [Output, SerializeField] public RoomBase down;
      
        
        public override object GetValue(NodePort port)
        {

            RoomBase result = null;
            
            if (port.fieldName == "left") {
                result =  GetInputValue<RoomBase>("right", null);
            }
            
            else if (port.fieldName == "up") {
                result =  GetInputValue<RoomBase>("down", null);
            }
            
            else if (port.fieldName == "right") {
                result =  GetInputValue<RoomBase>("left", null);
            }
            
            else if (port.fieldName == "down") {
                result =  GetInputValue<RoomBase>("up", null);
            }
            
            
            // Hopefully this won't ever happen, but we need to return something
            // in the odd case that the port isn't "result"
            return result;
        }
    }
}