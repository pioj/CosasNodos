﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XNode;

namespace pioj.PipoNodes
{
    public class Torre_01 : RoomBase
    {
        [Input, SerializeField] public RoomBase up;
        [Output, SerializeField] public RoomBase down;
        
        public override object GetValue(NodePort port)
        {

            RoomBase result = null;
           
           if (port.fieldName == "up") {
                result =  GetInputValue<RoomBase>("down", null);
            }
            
            else if (port.fieldName == "down") {
                result =  GetInputValue<RoomBase>("up", null);
            }
            
            
            // Hopefully this won't ever happen, but we need to return something
            // in the odd case that the port isn't "result"
            return result;
        }
    }
}