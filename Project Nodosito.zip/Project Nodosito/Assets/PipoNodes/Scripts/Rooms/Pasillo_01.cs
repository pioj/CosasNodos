﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.WSA;
using XNode;

namespace pioj.PipoNodes
{
    public class Pasillo_01 : RoomBase
    {
        [Input, SerializeField] public RoomBase left;
        [Output, SerializeField] public RoomBase right;
        
        public override object GetValue(NodePort port)
        {

            RoomBase result = null;
            
            if (port.fieldName == "left") {
                result =  GetInputValue<RoomBase>("right", null);
            }
            

            else if (port.fieldName == "right")
            {
                result = GetInputValue<RoomBase>("left", null);
            }
            
            // Hopefully this won't ever happen, but we need to return something
            // in the odd case that the port isn't "result"
            return result;
        }
    }
}

