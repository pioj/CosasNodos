﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using XNode;
using XNodeEditor;


namespace pioj.PipoNodes {

    [Serializable,CreateAssetMenu(fileName = "Pizarra_xxx", menuName = "pioj/PipoNodes/New Pizarra...")]
    public class Pizarra : NodeGraph
    {
        [MenuItem("PipoNodes/Open Pizarra")]
        public static void OpenPizarra()
        {
            var son = AssetDatabase.FindAssets("Pizarra t:NodeGraph");
            if (son == null | son.Length < 1) return;
            
            var moco= AssetDatabase.GUIDToAssetPath(son[0]);
            if (moco == null | moco.Length < 1) return;

            var soj = AssetDatabase.LoadAssetAtPath(moco,typeof(NodeGraph));
            AssetDatabase.OpenAsset(soj);
        }
    }

}