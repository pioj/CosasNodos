﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[Serializable]
public struct RoomJson
{
    [SerializeField] public string name;
    [SerializeField] public List<string> inputs;
    [SerializeField] public List<string> outputs;

    public RoomJson(string nam)
    {
        name = nam;
        inputs = new List<string>();
        outputs = new List<string>();
    }
}

[Serializable]
public class PizarraJson 
{
    [SerializeField] public string name;
    [SerializeField] public List<RoomJson> rooms = new List<RoomJson>();

    public PizarraJson(string nam)
    {
        name = nam;
    }
}
