using System;
using UnityEditor;
using UnityEngine;

public class Connex
{
    public ConnexPoint inPoint;
    public ConnexPoint outPoint;
    public Action<Connex> OnClickRemoveConnection;

    public Connex(ConnexPoint inPoint, ConnexPoint outPoint, Action<Connex> OnClickRemoveConnection)
    {
        this.inPoint = inPoint;
        this.outPoint = outPoint;
        this.OnClickRemoveConnection = OnClickRemoveConnection;
    }

    public void Draw()
    {
        //Handles.color = Color.white;
        Handles.DrawLine(
            inPoint.rect.center,
            outPoint.rect.center,
            2f
            );

        if (Handles.Button((inPoint.rect.center + outPoint.rect.center) * 0.5f, Quaternion.identity, 4, 8, Handles.RectangleHandleCap))
        {
            if (OnClickRemoveConnection != null)
            {
                OnClickRemoveConnection(this);
            }
        }
        
    }
}
