using UnityEngine;

[System.Serializable, CreateAssetMenu(fileName = "Bloque_001",menuName = "!Evolis3D/new Bloque ...")]
public class SO_Bloque : ScriptableObject
{
    public GUIContent paco;
}

[System.Serializable]
public class MiBloque
{
    public GUIContent paco;
}
