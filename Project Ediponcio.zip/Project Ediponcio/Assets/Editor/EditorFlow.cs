using System;
using UnityEngine;
using UnityEditor;
using System.Collections.Generic;

public class EditorFlow : EditorWindow
{
    public Action OnRemoveNode;

    private GUIContent currentBloque;
    
    private Vector2 drag;
    private Vector2 offset;

    private const int MOUSEBUTTON_LEFT = 0;
    private const int MOUSEBUTTON_RIGHT = 1;
    private const int MOUSEBUTTON_CENTER = 2;
    
    [MenuItem("!Evolis3D/Open EditorFlow...")]
    private static void OpenWindow()
    {
        EditorFlow window = GetWindow<EditorFlow>();
        window.titleContent = new GUIContent("Node Based Editor");
    }

    private void OnGUI()
    {
        DrawGrid(20, 0.2f, Color.gray);
        DrawGrid(100, 0.4f, Color.gray);
        
        DrawNodes();

        ProcessEvents(Event.current);

        if (GUI.changed) Repaint();
    }

    private void DrawNodes()
    {
        if (currentBloque!= null)
        {
            //GUI.Box(new Rect(10, 10, 64,64),currentBloque);
            GUI.DrawTexture(new Rect(10,10,64,64),currentBloque.image);
        } 
    }

    private void ProcessEvents(Event e)
    {
        drag = Vector2.zero;
 
        switch (e.type)
        {
            //la selección del Bloque
            case EventType.ExecuteCommand:
                if (e.commandName == "ObjectSelectorUpdated")
                {
                    var assetBloque = EditorGUIUtility.GetObjectPickerObject();
                    if (!assetBloque) return;
                    
                    var tempmsg = $"[EditorFlow] Selected Bloque: {assetBloque.name}";
                    Debug.Log(tempmsg);
                    var tempBloque = assetBloque as SO_Bloque;
                    currentBloque = tempBloque.paco;

                }
                break;
            
            case EventType.MouseDown:
                if (e.button == MOUSEBUTTON_LEFT)
                {
                    //ClearConnectionSelection();
                }
 
                if (e.button == MOUSEBUTTON_RIGHT)
                {
                    ProcessContextMenu(e.mousePosition);
                }
                break;

 
            case EventType.MouseDrag:
                if (e.button == MOUSEBUTTON_CENTER)
                {
                    OnDrag(e.delta);
                }
                break;
            
        }
    }
    
    private void OnDrag(Vector2 delta)
    {
        drag = delta;
 
        /*
        if (nodes != null)
        {
            for (int i = 0; i < nodes.Count; i++)
            {
                nodes[i].Drag(delta);
            }
        }
        */
 
        GUI.changed = true;
    }
    
    private void DrawGrid(float gridSpacing, float gridOpacity, Color gridColor)
    {
        int widthDivs = Mathf.CeilToInt(position.width / gridSpacing);
        int heightDivs = Mathf.CeilToInt(position.height / gridSpacing);
 
        Handles.BeginGUI();
        Handles.color = new Color(gridColor.r, gridColor.g, gridColor.b, gridOpacity);
 
        offset += drag * 0.5f;
        Vector3 newOffset = new Vector3(offset.x % gridSpacing, offset.y % gridSpacing, 0);
 
        for (int i = 0; i < widthDivs; i++)
        {
            Handles.DrawLine(new Vector3(gridSpacing * i, -gridSpacing, 0) + newOffset, new Vector3(gridSpacing * i, position.height, 0f) + newOffset);
        }
 
        for (int j = 0; j < heightDivs; j++)
        {
            Handles.DrawLine(new Vector3(-gridSpacing, gridSpacing * j, 0) + newOffset, new Vector3(position.width, gridSpacing * j, 0f) + newOffset);
        }
 
        Handles.color = Color.white;
        Handles.EndGUI();
    }
    
    private void ProcessContextMenu(Vector2 mousePosition)
    {
        GenericMenu genericMenu = new GenericMenu();
        
        genericMenu.AddItem(new GUIContent("Add Room"), false, () => OnClickAddRoom(mousePosition));
        
        genericMenu.AddDisabledItem(new GUIContent("Add Node/Controlled by Boolean"));
        genericMenu.AddDisabledItem(new GUIContent("Add Node/Controlled by Enum"));
        genericMenu.AddSeparator("");
        genericMenu.AddItem(new GUIContent("Re-center Screen"), false, () => OnRecenterScreen());
        genericMenu.ShowAsContext();
    }

    private void OnClickAddRoom(Vector2 mousepos)
    {
        //var path = EditorUtility.OpenFilePanelWithFilters("Load Bloque...", Application.dataPath, new string[] {"asset", "asset"});
        //var path = "Assets/Editor/Bloque_001.asset";
        //var bloque = AssetDatabase.LoadAssetAtPath<SO_Bloque>(path);
        //currentBloque = bloque.paco;
        EditorGUIUtility.ShowObjectPicker<SO_Bloque>(null,false,"Bloque",0);
    }

    private void OnClickRemoveNode()
    {
        if (OnRemoveNode != null)
        {
            OnRemoveNode();
        }
    }

    private void OnRecenterScreen()
    {
    }



}