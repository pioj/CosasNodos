﻿using XNode;

public class BranchNode : Node 
{ 
    [Input] public Node from;
    public int value;

    [Output] public Node Then;
    [Output] public Node Else;

    public override object GetValue(NodePort port) {
        if (port.fieldName == "b") return GetInputValue<Node>("from", from);
        else return null;
    }
}
