﻿using UnityEngine;
using XNode;

[CreateAssetMenu]
public class SimpleGraph : NodeGraph { }
